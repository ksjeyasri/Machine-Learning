import pandas as pd
import joblib

# Load saved pipeline
pipeline = joblib.load("alzheimers_xgb_model.pkl")

# Load new patients
new_data = pd.read_csv("new_patients.csv").dropna(how="all")

# Predict probabilities
probs = pipeline.predict_proba(new_data)[:, 1]
percentages = (probs * 100).round(2)

# Predictions with threshold
preds = (probs >= 0.5).astype(int)
labels = ["No Alzheimer's" if p==0 else "Alzheimer's" for p in preds]

# Add to DataFrame
new_data["Alzheimers_Probability_%"] = percentages
new_data["Prediction"] = labels

# Save to Excel
new_data.to_excel("new_patients_predictions.xlsx", index=False)
